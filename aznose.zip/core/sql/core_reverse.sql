DELETE from core_wards;
TRUNCATE TABLE core_wards RESTART IDENTITY;
DELETE from core_wards_level;
TRUNCATE TABLE core_wards_level RESTART IDENTITY;

DELETE from core_district;
TRUNCATE TABLE core_district RESTART IDENTITY;
DELETE from core_district_level;
TRUNCATE TABLE core_district_level RESTART IDENTITY;

DELETE from core_province;
TRUNCATE TABLE core_province RESTART IDENTITY;
DELETE from core_province_level;
TRUNCATE TABLE core_province_level RESTART IDENTITY;