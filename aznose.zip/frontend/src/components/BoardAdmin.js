import React from "react";

export default function BoardAdmin() {
  return <div></div>;
}
