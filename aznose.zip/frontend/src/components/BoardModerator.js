import React from "react";

export default function BoardModerator() {
  return <div></div>;
}
