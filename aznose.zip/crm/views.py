from django_filters.filters import DateFromToRangeFilter
from rest_framework import mixins
from rest_framework.viewsets import GenericViewSet
from aznose.pagination import StandardPagination
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from crm.serializers import *
from authentication.models import User
from rest_framework import viewsets
from django.shortcuts import get_object_or_404, render
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from rest_framework import status
from django.db.models import Q
from rest_framework import pagination
from django_filters import rest_framework as filters
import unidecode


class CRUDCustomerPriorityView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = CustomerPrioritySerializer
    queryset = CustomerPriority.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CustomerFilter(filters.FilterSet):
    created_date = DateFromToRangeFilter()
    fullname = filters.CharFilter()
    phone = filters.CharFilter()
    code = filters.CharFilter()
    #email = filters.CharFilter()

    class Meta:
        model = Customer
        fields = {'created_date': ['exact'],
                  'fullname': ['exact', 'icontains'],
                  'phone': ['exact', 'icontains'],
                  'code': ['exact', 'icontains'],
                  }


class CustomerView(viewsets.ModelViewSet):
    permission_classes = (AllowAny,)
    serializer_class = CustomerSerializer
    queryset = Customer.objects.all()
    lookup_field = 'id'
    pagination_class = StandardPagination
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_class = CustomerFilter
    # filterset_fields = {
    #     'created_date': ['gte', 'lte', 'exact', 'gt', 'lt'],
    # }
    # search_fields = []

    def get_queryset(self):
        queryset = super().get_queryset()
        # search = self.kwargs['search']
        search = self.request.query_params.get('search', None)
        if search is None:
            return queryset.order_by('-created_date')
        unaccented_search = unidecode.unidecode(search)
        if search != unaccented_search:
            queryset = queryset.filter(
                Q(fullname__icontains=search))
        else:
            queryset = queryset.filter(
                Q(fullname__unaccent__icontains=search) |
                Q(code__icontains=search) |
                Q(phone__icontains=search))

        return queryset.order_by('-created_date')


class CRUDCustomerSourceView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = CustomerSourceSerializer
    queryset = CustomerSource.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDAppointmentView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = AppointmentSerializer
    queryset = Appointment.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDStaffView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = StaffSerializer
    queryset = Staff.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDAppointmentStatusView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = AppointmentStatusSerializer
    queryset = AppointmentStatus.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDUIObjectView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = UIObjectSerializer
    queryset = UIObject.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDRoleView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = RoleSerializer
    queryset = Role.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDUserRoleView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = UserRoleSerializer
    queryset = UserRole.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDRolePermissionView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = RolePermissionSerializer
    queryset = RolePermission.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class CRUDPermissionView(viewsets.GenericViewSet, ListCreateAPIView, RetrieveUpdateDestroyAPIView):
    serializer_class = PermissionSerializer
    queryset = Permission.objects.all()
    permission_classes = (AllowAny,)
    lookup_field = 'id'


class DepartmentViewSet(viewsets.ModelViewSet):
    serializer_class = DepartmentSerializer
    queryset = Department.objects.all()
    lookup_field = 'id'
    permission_classes = (AllowAny,)


class CustomerTransferView(viewsets.ModelViewSet):
    serializer_class = CustomerTransferSerializer
    queryset = CustomerTransfer.objects.all()
    lookup_field = 'id'
    pagination_class = StandardPagination
    permission_classes = (AllowAny,)

    def get_queryset(self):
        queryset = super().get_queryset()
        # search = self.kwargs['search']
        search = self.request.query_params.get('search', None)
        if search is None:
            return queryset.order_by('-transfer_date')
        unaccented_search = unidecode.unidecode(search)
        if search != unaccented_search:
            queryset = queryset.filter(
                Q(customer__fullname__icontains=search))
        else:
            queryset = queryset.filter(
                Q(customer__fullname__unaccent__icontains=search) |
                Q(customer__code__icontains=search) |
                Q(customer__phone__icontains=search))

        return queryset.order_by('-transfer_date')


class CustomerTransferHistoryFilter(filters.FilterSet):
    transfer_date = DateFromToRangeFilter()

    fullname = filters.CharFilter(
        field_name='customer__fullname', lookup_expr='icontains')
    phone = filters.CharFilter(
        field_name='customer__phone', lookup_expr='icontains')
    code = filters.CharFilter(
        field_name='customer__code', lookup_expr='icontains')
    #email = filters.CharFilter()

    class Meta:
        model = CustomerTransferHistory

        fields = {
            # 'transfer_date': ['exact'],
            #   'customer__fullname': ['exact', 'icontains'],
            #           #   'phone': ['exact', 'icontains'],
            #           #   'code': ['exact', 'icontains'],
        }


class CustomerTransferHistoryView(mixins.RetrieveModelMixin, mixins.ListModelMixin, GenericViewSet):
    serializer_class = CustomerTransferHistorySerializer
    queryset = CustomerTransferHistory.objects.all()
    lookup_field = 'id'
    pagination_class = StandardPagination
    permission_classes = (AllowAny,)
    #filter_backends = (filters.DjangoFilterBackend,)
    filterset_class = CustomerTransferHistoryFilter

    def get_queryset(self):
        queryset = super().get_queryset()
        # search = self.kwargs['search']
        search = self.request.query_params.get('search', None)
        if search is None:
            return queryset.order_by('-transfer_date')

        unaccented_search = unidecode.unidecode(search)
        if search != unaccented_search:
            queryset = queryset.filter(
                Q(customer__fullname__icontains=search))
        else:
            queryset = queryset.filter(
                Q(customer__fullname__unaccent__icontains=search) |
                Q(customer__code__icontains=search) |
                Q(customer__phone__icontains=search))

        return queryset.order_by('-transfer_date')
