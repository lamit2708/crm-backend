
from rest_framework import serializers
from .models import *


class CustomerPrioritySerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerPriority
        fields = '__all__'


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'


class CustomerSourceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerSource
        fields = '__all__'


class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = '__all__'


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class StaffSerializer(serializers.ModelSerializer):
    class Meta:
        model = Staff
        fields = '__all__'


class AppointmentStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = AppointmentStatus
        fields = '__all__'


class UIObjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = UIObject
        fields = '__all__'


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = '__all__'


class UserRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserRole
        fields = '__all__'


class RolePermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = RolePermission
        fields = '__all__'


class PermissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Permission
        fields = '__all__'


class CustomerTransferSerializer(serializers.ModelSerializer):
    #customer_info = serializers.SerializerMethodField()
    fullname = serializers.SerializerMethodField()
    code = serializers.SerializerMethodField()
    department_name = serializers.SerializerMethodField()

    class Meta:
        model = CustomerTransfer
        #fields = '__all__'
        fields = ('id', 'customer', 'code', 'fullname',
                  'department', 'department_name', 'note', 'transfer_user', 'transfer_date', 'process_user')

    def get_fullname(self, obj):
        if obj.customer is not None:
            return obj.customer.fullname

    def get_code(self, obj):
        if obj.customer is not None:
            return obj.customer.code

    def get_department_name(self, obj):
        if obj.department is not None:
            return obj.department.name

    def get_customer_info(self, obj):
        # https://stackoverflow.com/questions/42775784/how-to-serialize-a-queryset-from-an-unrelated-model-as-a-nested-serializer?rq=1
        customer_id = obj.customer.id
        queryset = Customer.objects.get(id=customer_id)
        return CustomerSerializer(queryset, read_only=True).data


class CustomerTransferHistorySerializer(serializers.ModelSerializer):
    #customer_info = serializers.SerializerMethodField()
    fullname = serializers.SerializerMethodField()
    code = serializers.SerializerMethodField()
    phone = serializers.SerializerMethodField()
    department_name = serializers.SerializerMethodField()
    transfer_user_fullname = serializers.SerializerMethodField()
    process_user_fullname = serializers.SerializerMethodField()

    class Meta:
        model = CustomerTransferHistory
        #fields = '__all__'
        fields = ('id', 'customer_transfer_id', 'customer', 'code', 'fullname', 'phone',
                  'department', 'department_name', 'note', 'transfer_user',
                  'transfer_user_fullname', 'transfer_date', 'process_user',
                  'process_user_fullname')

    def get_fullname(self, obj):
        return obj.customer.fullname

    def get_code(self, obj):
        # if obj.customer is not None:
        return obj.customer.code

    def get_phone(self, obj):
        return obj.customer.phone

    def get_department_name(self, obj):
        return obj.department.name

    def get_transfer_user_fullname(self, obj):
        if obj.transfer_user is not None:
            return obj.transfer_user.fullname

    def get_process_user_fullname(self, obj):
        if obj.process_user is not None:
            return obj.process_user.fullname


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = '__all__'
