from rest_framework import routers
import register
from . import views

# Register router
crmRouter = routers.SimpleRouter()
crmRouter.register('customer-priority', views.CRUDCustomerPriorityView)
crmRouter.register('customer', views.CustomerView)
crmRouter.register('customer-source', views.CRUDCustomerSourceView)
crmRouter.register('appointment', views.CRUDAppointmentView)
#router.register('user', views.CRUDUserView)
crmRouter.register('staff', views.CRUDStaffView)
crmRouter.register('appointment-status', views.CRUDAppointmentStatusView)
crmRouter.register('ui-object', views.CRUDUIObjectView)
crmRouter.register('role', views.CRUDRoleView)
crmRouter.register('user-role', views.CRUDUserRoleView)
crmRouter.register('role-permission', views.CRUDRolePermissionView)
crmRouter.register('permission', views.CRUDPermissionView)
crmRouter.register('department', views.DepartmentViewSet)
crmRouter.register('customer-transfer', views.CustomerTransferView)
crmRouter.register('customer-transfer-history',
                   views.CustomerTransferHistoryView)
