from django.contrib import admin
from .models import *
from authentication.models import *

admin.site.register(CustomerPriority)
admin.site.register(Customer)
admin.site.register(CustomerSource)
admin.site.register(Appointment)
# admin.site.register(User)
admin.site.register(Staff)
admin.site.register(AppointmentStatus)
admin.site.register(UIObject)
admin.site.register(Role)
admin.site.register(UserRole)
admin.site.register(RolePermission)
admin.site.register(Permission)
