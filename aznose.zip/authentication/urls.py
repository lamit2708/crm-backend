from django.urls import path
from rest_framework_simplejwt import views as jwt_views
#from .views import ObtainTokenPairWithColorView, UserCreate, HelloWorldView
from . import views
from rest_framework import routers
from django.conf.urls import url, include

# Register router
router = routers.SimpleRouter()
router.register('user', views.UserViewSet)

urlpatterns = [
    # path('token/obtain/', jwt_views.TokenObtainPairView.as_view(), name='token_create'),  # override sjwt stock token
    path('api/token/', views.ObtainTokenPairWithColorView.as_view(),
         name='token_create'),
    path('api/token/refresh/', jwt_views.TokenRefreshView.as_view(),
         name='token_refresh'),
    # path('api/user/create/', views.UserCreate.as_view(), name="create_user"),
    path('api/', include(router.urls)),

]
